import "./UserCard.css"

function UserCard(props) {
    return (
        <div>
            <div className="card azul p-3" style={{ zIndex: "4" }}>
                <img className='imm'  src={`${props.man}`}/>
                <div className="card-body writ text-start">
                    <p className='writ text-start bn'>Report for</p>
                    <h1> {props.nombre} </h1>
                </div>
            </div>

            <div className="card text-start morado" style={{ marginTop: "-20px" }}>
                <div className='par'>
                    <p className='let'>Daily</p>
                    <p className='let'>Weekly</p>
                    <p className='let bn'>Monthly</p>
                </div>
            </div>
        
        </div>
    )
}


export default UserCard